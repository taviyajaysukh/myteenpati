<template>
    <ion-page>
        <ion-header :translucent="true">
            <ion-toolbar color="primary">
                <ion-title style="display:inline-block">
                    <ion-icon :icon="arrowBack" @click="() => router.go(-1)" /><span class="ion-margin-start">Interest</span>
                </ion-title>
                <ion-button slot="end" @click="presentAlert">
                    <ion-icon :icon="helpCircle" />
            </ion-button>
            </ion-toolbar>
        </ion-header>
        <ion-content>
            <ion-grid>
                <ion-row class="border-bottom-ctm">
                    <ion-col>
                        <ion-text>
                           Record not found
                        </ion-text>
                    </ion-col>
                </ion-row>
               
            </ion-grid>
        </ion-content>
        <ion-footer>
            <h1>Footer</h1>
            <FooterPage />
        </ion-footer>
    </ion-page>
</template>
<script lang="ts">
import {
    IonContent, IonPage, IonHeader, IonToolbar, IonGrid, IonRow, IonCol,IonIcon,IonTitle,IonText,IonButton,IonFooter,alertController
} from '@ionic/vue';
import { defineComponent } from 'vue';
import FooterPage from '../include/FooterPage.vue'
import { arrowBack,helpCircle } from 'ionicons/icons';
import { useRouter } from 'vue-router';

export default defineComponent({
    name: 'InterestPage',
    components: {
        IonContent, IonPage, IonHeader, IonToolbar, IonGrid, IonRow, IonCol,IonIcon,IonTitle,IonText,IonButton,IonFooter, FooterPage
    },
    setup() {
        const router = useRouter();
        return {
            arrowBack, helpCircle,router
        }
    },
    data(){
        return{
            currentUser:''
        }
    },
    ionViewDidEnter() {
    this.currentUser = localStorage.getItem('session_user') || '';
    if (Object.keys(this.currentUser).length == 0) {
      this.router.push('/my/login')
    }
    this.presentAlert();
  },
    methods: {
    async presentAlert() {
      const alert = await alertController.create({
        header: 'Explain',
        cssClass: 'my-custom-class',
        message: 'Interest rules:1. The account balance is greater than 500 to generate interest2. Settlement time is 12:00 every day, and the profit amount enters the balance account3. Interest amount 1000*0.008=8',
        buttons: ['Close'],
      });
      await alert.present();
    },
    logout() {
      localStorage.clear();
      this.router.push('my/login')
    },
    segmentChanged(ev: CustomEvent) {
      console.log(ev.detail.value)
      //this.segmentModel = ev.detail.value;
    }
  }
});
</script>
<style scoped>
.border-bottom-ctm{
    border-bottom:2px solid gray;
    padding:5px;
}
</style>